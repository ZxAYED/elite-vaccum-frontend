import { notFound } from "next/navigation";

import { AdminTechnicianDetailClient } from "@/components/admin/technicians/AdminTechnicianDetailClient";
import { getAdminTechnicianById } from "@/data/mock/technicians";

interface AdminTechnicianDetailPageProps {
  params: Promise<{
    technicianId: string;
  }>;
}

export default async function AdminTechnicianDetailPage({
  params,
}: AdminTechnicianDetailPageProps) {
  const { technicianId } = await params;

  if (!getAdminTechnicianById(technicianId)) {
    notFound();
  }

  return <AdminTechnicianDetailClient technicianId={technicianId} />;
}
